This is a replay pack: a signed export of what was recorded for one job.

Check it with ares-verify (open source):

    ares-verify <this file>.zip

A PASS means the records were not edited, removed or reordered after export,
each record matches the ledger write it points at, and the listed
organisations endorsed those writes with their own keys.

A PASS does not mean the agents' outputs were correct, that nothing happened
outside the recording path, or that the pack holds every record that exists.
